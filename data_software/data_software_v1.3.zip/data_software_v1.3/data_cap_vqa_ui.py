import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton,
    QLineEdit, QFileDialog, QProgressBar, QComboBox, QGroupBox
)
from PyQt5.QtCore import Qt

class DataCapVQAModule(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.setup_style()

    def setup_style(self):
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #444466;
                border-radius: 8px;
                margin-top: 1em;
                padding-top: 10px;
                background-color: rgba(30, 30, 50, 180);
                color: #c0c0e0;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QLabel {
                color: #c0c0e0;
            }
            QPushButton {
                background-color: rgba(60, 60, 100, 200);
                color: #e0e0ff;
                border: 1px solid #4a4a7a;
                border-radius: 4px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: rgba(80, 80, 130, 220);
                border: 1px solid #6a6aaa;
            }
            QPushButton:pressed {
                background-color: rgba(100, 100, 160, 240);
            }
            QLineEdit, QTextEdit {
                background-color: rgba(25, 25, 40, 200);
                color: #e0e0ff;
                border: 1px solid #444466;
                border-radius: 4px;
                padding: 5px;
            }
            QProgressBar {
                border: 1px solid #444466;
                border-radius: 4px;
                text-align: center;
                background-color: rgba(20, 20, 35, 200);
            }
            QProgressBar::chunk {
                background-color: #4a86e8;
                border-radius: 4px;
            }
        """)

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 标题
        title = QLabel("视觉-语言任务衍生数据生成 (Image Caption & Visual QA)")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #8ab4f8;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # 开发中提示
        dev_label = QLabel("功能开发中")
        dev_label.setStyleSheet("font-size: 16px; color: #ffaa44; font-weight: bold;")
        dev_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(dev_label)
        
        # 配置区域
        config_group = QGroupBox("模型配置")
        config_layout = QVBoxLayout()
        
        # API设置
        api_layout = QHBoxLayout()
        api_layout.addWidget(QLabel("API地址:"))
        self.api_url_edit = QLineEdit("http://localhost:8089/v1")
        api_layout.addWidget(self.api_url_edit, 3)
        
        api_layout.addWidget(QLabel("API密钥:"))
        self.api_key_edit = QLineEdit("no-api-key-required")
        api_layout.addWidget(self.api_key_edit, 2)
        config_layout.addLayout(api_layout)
        
        # 模型选择
        model_layout = QHBoxLayout()
        model_layout.addWidget(QLabel("模型选择:"))
        self.model_combo = QComboBox()
        self.model_combo.addItems(["InternVL3-8B", "InternVL2-6B", "InternVL1-5B"])
        model_layout.addWidget(self.model_combo, 2)
        
        model_layout.addStretch(1)
        config_layout.addLayout(model_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # 数据设置
        data_group = QGroupBox("数据设置")
        data_layout = QVBoxLayout()
        
        # 图像文件夹
        img_layout = QHBoxLayout()
        img_layout.addWidget(QLabel("图像文件夹:"))
        self.img_path_edit = QLineEdit()
        img_layout.addWidget(self.img_path_edit, 3)
        
        img_btn = QPushButton("浏览")
        img_btn.clicked.connect(self.select_img_path)
        img_layout.addWidget(img_btn, 1)
        data_layout.addLayout(img_layout)
        
        # 标签文件夹
        label_layout = QHBoxLayout()
        label_layout.addWidget(QLabel("标签文件夹:"))
        self.label_path_edit = QLineEdit()
        label_layout.addWidget(self.label_path_edit, 3)
        
        label_btn = QPushButton("浏览")
        label_btn.clicked.connect(self.select_label_path)
        label_layout.addWidget(label_btn, 1)
        data_layout.addLayout(label_layout)
        
        # 输出文件夹
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("输出文件夹:"))
        self.output_path_edit = QLineEdit()
        output_layout.addWidget(self.output_path_edit, 3)
        
        output_btn = QPushButton("浏览")
        output_btn.clicked.connect(self.select_output_path)
        output_layout.addWidget(output_btn, 1)
        data_layout.addLayout(output_layout)
        
        # 处理参数
        param_layout = QHBoxLayout()
        param_layout.addWidget(QLabel("分块大小:"))
        self.chunk_size_edit = QLineEdit("1024")
        param_layout.addWidget(self.chunk_size_edit)
        
        param_layout.addWidget(QLabel("分块数量:"))
        self.chunk_num_edit = QLineEdit("5")
        param_layout.addWidget(self.chunk_num_edit)
        
        param_layout.addStretch()
        data_layout.addLayout(param_layout)
        
        data_group.setLayout(data_layout)
        layout.addWidget(data_group)
        
        # 处理控制
        process_group = QGroupBox("处理控制")
        process_layout = QVBoxLayout()
        
        # 提示词
        prompt_layout = QHBoxLayout()
        prompt_layout.addWidget(QLabel("提示词:"))
        self.prompt_edit = QTextEdit()
        self.prompt_edit.setPlainText(
            "请详细描述这张图像的内容，包括主要物体、场景、颜色、动作和物体间的相互关系等元素。要求描述细致准确，重点关注军事情报相关信息。"
        )
        self.prompt_edit.setMaximumHeight(80)
        prompt_layout.addWidget(self.prompt_edit, 1)
        process_layout.addLayout(prompt_layout)
        
        # 按钮区域
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始生成")
        self.start_btn.setStyleSheet("background-color: rgba(80, 150, 80, 200);")
        self.start_btn.clicked.connect(self.start_generation)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("停止生成")
        self.stop_btn.setStyleSheet("background-color: rgba(180, 80, 80, 200);")
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.stop_btn)
        process_layout.addLayout(btn_layout)
        
        # 进度条
        progress_layout = QHBoxLayout()
        self.progress_label = QLabel("就绪")
        progress_layout.addWidget(self.progress_label)
        
        self.progress_bar = QProgressBar()
        progress_layout.addWidget(self.progress_bar)
        process_layout.addLayout(progress_layout)
        
        # 日志显示
        log_layout = QVBoxLayout()
        log_layout.addWidget(QLabel("处理日志:"))
        
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        log_layout.addWidget(self.log_display)
        process_layout.addLayout(log_layout)
        
        process_group.setLayout(process_layout)
        layout.addWidget(process_group, 1)
        
        self.setLayout(layout)

    def select_img_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择图像文件夹")
        if path:
            self.img_path_edit.setText(path)

    def select_label_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择标签文件夹")
        if path:
            self.label_path_edit.setText(path)

    def select_output_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择输出文件夹")
        if path:
            self.output_path_edit.setText(path)

    def start_generation(self):
        # 模拟生成过程
        self.log_display.append("开始处理图像数据...")
        self.progress_bar.setRange(0, 100)
        
        # 创建动画效果
        self.animation = QPropertyAnimation(self.progress_bar, b"value")
        self.animation.setDuration(5000)
        self.animation.setStartValue(0)
        self.animation.setEndValue(100)
        self.animation.setEasingCurve(QEasingCurve.InOutQuad)
        self.animation.start()
        
        # 更新日志
        self.log_display.append("加载模型: InternVL3-8B...")
        self.log_display.append("处理图像块 1/5...")
        self.log_display.append("生成描述: 图像中包含多架商业客机停放在机场...")
        self.log_display.append("生成问答对: Q: 机场上有多少架飞机? A: 机场上共有12架飞机...")
        self.log_display.append("处理图像块 2/5...")
        self.log_display.append("处理完成! 共生成1200个描述和问答对")