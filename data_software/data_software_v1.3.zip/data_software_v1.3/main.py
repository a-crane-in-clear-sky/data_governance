import os
import sys
import json
import datetime
import base64
import io
import re
import argparse
import shutil
import threading
import queue
from tqdm import tqdm
from openai import OpenAI, BadRequestError
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QLineEdit, QPushButton, QLabel, QTextEdit, QFileDialog, QProgressBar,
    QShortcut, QGroupBox, QSizePolicy, QFrame, QMenu, QAction, QMessageBox,
    QStackedWidget, QToolBar, QScrollArea, QListWidget, QInputDialog, QComboBox,
    QListWidgetItem, QStatusBar, QSizeGrip
)
from PyQt5.QtGui import (
    QPixmap, QImage, QPainter, QPen, QColor, QKeySequence, QFont, QIcon, 
    QPalette, QLinearGradient, QBrush, QMovie
)
from PyQt5.QtCore import (
    Qt, QPoint, QThread, pyqtSignal, QSize, QPropertyAnimation, QEasingCurve,
    QTimer
)
from PIL import Image, ImageDraw


class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("多模态大模型训练数据管理平台")
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowIcon(QIcon("icons/CASC-LOGO.png"))
        
        # 初始化UI
        self.init_ui()
        self.setup_styles()
        
        # 初始化子模块（延迟加载）
        self.data_select_module = None
        self.data_cap_vqa_module = None
        self.data_refine_module = None
    
    def init_ui(self):
        # 主窗口布局
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        # 主布局（水平分割：侧边栏 + 内容区）
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # ==================== 左侧边栏 ====================
        self.sidebar = QWidget()
        self.sidebar.setFixedWidth(220)
        self.sidebar.setObjectName("sidebar")
        
        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setContentsMargins(10, 20, 10, 20)
        sidebar_layout.setSpacing(15)
        
        # 平台标题
        title = QLabel("数据管理平台")
        title.setObjectName("sidebarTitle")
        title.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(title)
        
        # 功能按钮
        self.btn_data_select = self.create_menu_button("图像数据筛选", "icons/data_select.png")
        self.btn_data_select.clicked.connect(lambda: self.switch_module(0))
        
        self.btn_data_cap_vqa = self.create_menu_button("视觉-语言任务衍生数据生成", "icons/data_cap_vqa.png")
        self.btn_data_cap_vqa.clicked.connect(lambda: self.switch_module(1))
        
        self.btn_data_refine = self.create_menu_button("视觉-语言任务衍生数据校正", "icons/data_refine.png")
        self.btn_data_refine.clicked.connect(lambda: self.switch_module(2))
        
        sidebar_layout.addWidget(self.btn_data_select)
        sidebar_layout.addWidget(self.btn_data_cap_vqa)
        sidebar_layout.addWidget(self.btn_data_refine)
        
        sidebar_layout.addStretch()
        
        # 版本信息
        version = QLabel("v1.0")
        version.setObjectName("versionLabel")
        sidebar_layout.addWidget(version)
        
        main_layout.addWidget(self.sidebar)
        
        # ==================== 右侧内容区 ====================
        self.content_area = QWidget()
        self.content_area.setObjectName("contentArea")
        
        content_layout = QVBoxLayout(self.content_area)
        content_layout.setContentsMargins(0, 0, 0, 0)
        
        # 堆叠窗口用于模块切换
        self.module_stack = QStackedWidget()
        content_layout.addWidget(self.module_stack)
        
        # 初始欢迎页面
        self.setup_welcome_page()
        
        main_layout.addWidget(self.content_area, 1)
    
    def setup_welcome_page(self):
        """初始欢迎页面"""
        welcome_page = QWidget()
        layout = QVBoxLayout(welcome_page)
        layout.setAlignment(Qt.AlignCenter)
        
        # 欢迎文字
        welcome_label = QLabel("欢迎使用多模态大模型训练数据管理平台")
        welcome_label.setObjectName("welcomeLabel")
        
        # 提示文字
        hint_label = QLabel("请从左侧菜单选择功能模块")
        hint_label.setObjectName("hintLabel")
        
        layout.addWidget(welcome_label)
        layout.addWidget(hint_label)
        
        self.module_stack.addWidget(welcome_page)
    
    def create_menu_button(self, text, icon_path):
        """创建统一的菜单按钮"""
        btn = QPushButton(text)
        btn.setCheckable(True)
        btn.setIcon(QIcon(icon_path))
        btn.setIconSize(QSize(24, 24))
        btn.setObjectName("menuButton")
        return btn
    
    def switch_module(self, index):
        """切换功能模块"""
        # 更新按钮状态
        self.btn_data_select.setChecked(index == 0)
        self.btn_data_cap_vqa.setChecked(index == 1)
        self.btn_data_refine.setChecked(index == 2)
        
        # 延迟加载模块
        if index == 0:  # 图像数据筛选
            if not hasattr(self, 'data_select_module') or self.data_select_module is None:
                try:
                    from data_select_ui import DataSelectUI  # 修改导入的类名
                    self.data_select_module = DataSelectUI()  # 使用新的UI类
                    self.module_stack.addWidget(self.data_select_module)
                except ImportError as e:
                    print(f"无法加载数据筛选模块: {e}")
                    return
            self.module_stack.setCurrentWidget(self.data_select_module)
        
        elif index == 1:  # 视觉-语言任务衍生数据生成
            if not hasattr(self, 'data_cap_vqa_module') or self.data_cap_vqa_module is None:
                try:
                    from data_cap_vqa_ui import DataCapVQAModule
                    self.data_cap_vqa_module = DataCapVQAModule()
                    self.module_stack.addWidget(self.data_cap_vqa_module)
                except ImportError as e:
                    print(f"无法加载数据生成模块: {e}")
                    return
            self.module_stack.setCurrentWidget(self.data_cap_vqa_module)
        
        elif index == 2:  # 视觉-语言任务衍生数据校正
            if not hasattr(self, 'data_refine_module') or self.data_refine_module is None:
                try:
                    from data_refine_ui import DataRefineModule
                    self.data_refine_module = DataRefineModule()
                    self.module_stack.addWidget(self.data_refine_module)
                except ImportError as e:
                    print(f"无法加载数据校正模块: {e}")
                    return
            self.module_stack.setCurrentWidget(self.data_refine_module)
    
    def setup_styles(self):
        """设置全局样式"""
        self.setStyleSheet("""
            #sidebar {
                background-color: #1a1a2e;
                border-right: 1px solid #333355;
            }
            #sidebarTitle {
                font-size: 18px;
                font-weight: bold;
                color: #8ab4f8;
                padding: 10px;
                border-bottom: 1px solid #333355;
            }
            #menuButton {
                background-color: rgba(60, 60, 100, 200);
                color: #e0e0ff;
                border: 1px solid #4a4a7a;
                border-radius: 8px;
                padding: 12px;
                text-align: left;
                font-size: 14px;
                font-weight: 500;
            }
            #menuButton:hover {
                background-color: rgba(80, 80, 130, 220);
                border: 1px solid #6a6aaa;
            }
            #menuButton:checked {
                background-color: rgba(80, 120, 200, 220);
                border: 1px solid #8ab4f8;
            }
            #contentArea {
                background-color: #0f0f1a;
            }
            #welcomeLabel {
                font-size: 24px;
                font-weight: bold;
                color: #8ab4f8;
                margin-bottom: 30px;
            }
            #hintLabel {
                font-size: 16px;
                color: #aaaaaa;
            }
            #versionLabel {
                color: #6a6a8a;
                font-size: 12px;
                text-align: center;
            }
        """)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # 设置应用字体
    font = QFont("Microsoft YaHei", 9)
    app.setFont(font)
    
    # 创建主窗口
    window = MainApp()
    window.show()
    
    sys.exit(app.exec_())