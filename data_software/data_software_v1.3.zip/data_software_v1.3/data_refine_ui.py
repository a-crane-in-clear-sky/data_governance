# data_refine.py
import os
import json
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton,
    QLineEdit, QFileDialog, QProgressBar, QScrollArea, QFrame, QSplitter,
    QGroupBox
)
from PyQt5.QtGui import QPixmap, QColor, QFont, QPainter
from PyQt5.QtCore import Qt

class DataRefineModule(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.setup_style()
        self.show_example_image()

    def setup_style(self):
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #444466;
                border-radius: 8px;
                margin-top: 1em;
                padding-top: 10px;
                background-color: rgba(30, 30, 50, 180);
                color: #c0c0e0;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QLabel {
                color: #c0c0e0;
            }
            QPushButton {
                background-color: rgba(60, 60, 100, 200);
                color: #e0e0ff;
                border: 1px solid #4a4a7a;
                border-radius: 4px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: rgba(80, 80, 130, 220);
                border: 1px solid #6a6aaa;
            }
            QPushButton:pressed {
                background-color: rgba(100, 100, 160, 240);
            }
            QLineEdit, QTextEdit {
                background-color: rgba(25, 25, 40, 200);
                color: #e0e0ff;
                border: 1px solid #444466;
                border-radius: 4px;
                padding: 5px;
            }
            QProgressBar {
                border: 1px solid #444466;
                border-radius: 4px;
                text-align: center;
                background-color: rgba(20, 20, 35, 200);
            }
            QProgressBar::chunk {
                background-color: #4a86e8;
                border-radius: 4px;
            }
            QScrollArea {
                border: 1px solid #444466;
                border-radius: 4px;
                background-color: rgba(25, 25, 40, 200);
            }
            QFrame {
                background-color: rgba(25, 25, 40, 200);
            }
        """)

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 标题
        title = QLabel("视觉-语言任务衍生数据高质量校正")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #8ab4f8;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # 配置区域
        config_group = QGroupBox("数据配置")
        config_layout = QVBoxLayout()
        
        # 图像文件夹
        img_layout = QHBoxLayout()
        img_layout.addWidget(QLabel("图像文件夹:"))
        self.img_path_edit = QLineEdit()
        img_layout.addWidget(self.img_path_edit, 3)
        
        img_btn = QPushButton("浏览")
        img_btn.clicked.connect(self.select_img_path)
        img_layout.addWidget(img_btn, 1)
        config_layout.addLayout(img_layout)
        
        # 标注文件夹
        ann_layout = QHBoxLayout()
        ann_layout.addWidget(QLabel("标注文件夹:"))
        self.ann_path_edit = QLineEdit()
        ann_layout.addWidget(self.ann_path_edit, 3)
        
        ann_btn = QPushButton("浏览")
        ann_btn.clicked.connect(self.select_ann_path)
        ann_layout.addWidget(ann_btn, 1)
        config_layout.addLayout(ann_layout)
        
        # JSON文件
        json_layout = QHBoxLayout()
        json_layout.addWidget(QLabel("JSON文件:"))
        self.json_path_edit = QLineEdit()
        json_layout.addWidget(self.json_path_edit, 3)
        
        json_btn = QPushButton("浏览")
        json_btn.clicked.connect(self.select_json_path)
        json_layout.addWidget(json_btn, 1)
        config_layout.addLayout(json_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # 主显示区域
        main_display = QSplitter(Qt.Horizontal)
        
        # 左侧图像面板
        image_frame = QFrame()
        image_layout = QVBoxLayout(image_frame)
        
        # 图像显示区域
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(400, 400)
        self.image_label.setStyleSheet("border: 1px solid #444466; background-color: rgba(20, 20, 35, 200);")
        
        # 滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.image_label)
        scroll_area.setWidgetResizable(True)
        image_layout.addWidget(scroll_area, 3)
        
        # 图像路径标签
        self.image_path_label = QLabel("图像路径: 尚未加载")
        image_layout.addWidget(self.image_path_label, 1)
        
        main_display.addWidget(image_frame)
        
        # 右侧文本面板
        text_frame = QFrame()
        text_layout = QVBoxLayout(text_frame)
        
        # 描述区域
        desc_label = QLabel("图像描述:")
        text_layout.addWidget(desc_label)
        
        self.desc_text = QTextEdit()
        self.desc_text.setMinimumHeight(100)
        text_layout.addWidget(self.desc_text, 1)
        
        # 描述来源标签
        self.desc_source_label = QLabel("描述来源: 尚未加载")
        text_layout.addWidget(self.desc_source_label)
        
        # 问答区域
        qa_label = QLabel("图文问答:")
        text_layout.addWidget(qa_label)
        
        self.qa_scroll = QScrollArea()
        self.qa_container = QWidget()
        self.qa_container_layout = QVBoxLayout(self.qa_container)
        self.qa_container_layout.setAlignment(Qt.AlignTop)
        self.qa_scroll.setWidget(self.qa_container)
        self.qa_scroll.setWidgetResizable(True)
        text_layout.addWidget(self.qa_scroll, 3)
        
        # 问答来源标签
        self.qa_source_label = QLabel("问答来源: 尚未加载")
        text_layout.addWidget(self.qa_source_label)
        
        main_display.addWidget(text_frame)
        
        layout.addWidget(main_display, 1)
        
        # 控制区域
        control_group = QGroupBox("数据校正控制")
        control_layout = QVBoxLayout()
        
        # 进度条
        progress_layout = QHBoxLayout()
        self.progress_label = QLabel("0/0")
        self.progress_label.setFixedWidth(80)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setFormat("%p% (%v/%m)")
        
        progress_layout.addWidget(self.progress_label)
        progress_layout.addWidget(self.progress_bar)
        control_layout.addLayout(progress_layout)
        
        # 导航按钮
        nav_layout = QHBoxLayout()
        self.prev_button = QPushButton("上一张 (←/↑)")
        nav_layout.addWidget(self.prev_button)
        
        self.next_button = QPushButton("下一张 (→/↓)")
        nav_layout.addWidget(self.next_button)
        control_layout.addLayout(nav_layout)
        
        # 操作按钮
        action_layout = QHBoxLayout()
        self.add_caption_btn = QPushButton("添加图像描述")
        action_layout.addWidget(self.add_caption_btn)
        
        self.add_vqa_btn = QPushButton("添加视觉问答对")
        action_layout.addWidget(self.add_vqa_btn)
        
        self.save_btn = QPushButton("保存标注 (Ctrl+S)")
        action_layout.addWidget(self.save_btn)
        control_layout.addLayout(action_layout)
        
        # 检测框按钮
        bbox_layout = QHBoxLayout()
        self.show_bbox_btn = QPushButton("显示检测框")
        bbox_layout.addWidget(self.show_bbox_btn)
        
        self.hide_bbox_btn = QPushButton("隐藏检测框")
        bbox_layout.addWidget(self.hide_bbox_btn)
        control_layout.addLayout(bbox_layout)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        self.setLayout(layout)

    def show_example_image(self):
        # 创建示例图像
        pixmap = QPixmap(600, 400)
        pixmap.fill(QColor(30, 30, 50))
        
        painter = QPainter(pixmap)
        painter.setPen(QColor(100, 180, 255))
        painter.setFont(QFont("Arial", 24))
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "图像预览区域")
        painter.end()
        
        self.image_label.setPixmap(pixmap)
        
        # 设置示例文本
        self.desc_text.setPlainText("图像描述示例：机场鸟瞰图，包含多架商业客机停放在停机坪上，远处有控制塔和候机楼。")
        
        # 添加示例问答
        self.add_qa_row("问：图像中有多少架飞机？", "答：图像中可见12架飞机停放在停机坪上。")
        self.add_qa_row("问：机场的主要设施有哪些？", "答：机场包含控制塔、候机楼、跑道和多个停机位。")

    def add_qa_row(self, question="", answer=""):
        """添加一个问答对行"""
        qa_frame = QFrame()
        qa_frame.setFrameShape(QFrame.StyledPanel)
        qa_frame.setStyleSheet("background-color: rgba(40, 40, 60, 150); border-radius: 6px;")
        qa_layout = QVBoxLayout(qa_frame)
        qa_layout.setContentsMargins(10, 10, 10, 10)
        
        # 问题标签
        q_label = QLabel("问题:")
        qa_layout.addWidget(q_label)
        
        # 问题文本框
        question_txt = QTextEdit()
        question_txt.setPlainText(question)
        question_txt.setMinimumHeight(50)
        qa_layout.addWidget(question_txt)
        
        # 答案标签
        a_label = QLabel("答案:")
        qa_layout.addWidget(a_label)
        
        # 答案文本框
        answer_txt = QTextEdit()
        answer_txt.setPlainText(answer)
        answer_txt.setMinimumHeight(80)
        qa_layout.addWidget(answer_txt)
        
        # 删除按钮
        btn_delete = QPushButton("删除此问答对")
        btn_delete.setStyleSheet("background-color: rgba(180, 80, 80, 150);")
        btn_delete.clicked.connect(lambda: self.delete_qa_row(qa_frame))
        qa_layout.addWidget(btn_delete)
        
        # 添加到容器
        self.qa_container_layout.addWidget(qa_frame)

    def delete_qa_row(self, frame):
        """删除特定的问答对行"""
        frame.deleteLater()

    def select_img_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择图像文件夹")
        if path:
            self.img_path_edit.setText(path)

    def select_ann_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择标注文件夹")
        if path:
            self.ann_path_edit.setText(path)

    def select_json_path(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择JSON文件", "", "JSON文件 (*.json)")
        if file_path:
            self.json_path_edit.setText(file_path)