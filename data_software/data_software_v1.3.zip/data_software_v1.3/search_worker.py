import os
import json
from PyQt5.QtCore import QThread, pyqtSignal

class SearchWorker(QThread):
    """后台工作线程，用于在搜索时处理JSON文件"""
    search_finished = pyqtSignal(list, str)  # 搜索完成信号
    progress_updated = pyqtSignal(int, int)  # 进度更新信号
    error_occurred = pyqtSignal(str)  # 错误信号
    
    def __init__(self, labels_path, search_term):
        super().__init__()
        self.labels_path = labels_path
        self.search_term = search_term
        self.running = True
    
    def run(self):
        """线程主执行函数"""
        try:
            if not os.path.exists(self.labels_path):
                self.error_occurred.emit(f"目录 {self.labels_path} 不存在！")
                return
                
            search_results = []
            json_files = [f for f in os.listdir(self.labels_path) if f.endswith(".json")]
            total_files = len(json_files)
            
            for idx, filename in enumerate(json_files):
                if not self.running:  # 检查是否已请求停止
                    return
                    
                filepath = os.path.join(self.labels_path, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        # 检查annotations中是否包含搜索词
                        if self.contains_search_term(data, self.search_term):
                            search_results.append(filename.replace(".json", ""))
                except Exception as e:
                    self.error_occurred.emit(f"读取文件 {filename} 出错: {str(e)}")
                    continue
                
                # 每处理5个文件更新一次进度，减少UI更新频率
                if idx % 5 == 0:
                    self.progress_updated.emit(idx + 1, total_files)
            
            # 确保最后100%更新
            self.progress_updated.emit(total_files, total_files)
            self.search_finished.emit(search_results, self.search_term)
            
        except Exception as e:
            self.error_occurred.emit(f"搜索过程中发生错误: {str(e)}")
    
    def contains_search_term(self, data, search_term):
        """检查JSON数据中是否包含搜索词（修改：空搜索词返回所有文件）"""
        # 如果搜索词为空，返回所有文件
        if not search_term.strip():
            return True
            
        if "annotations" in data:
            for annotation in data["annotations"]:
                if ("class" in annotation and search_term in annotation["class"]) or \
                   ("label" in annotation and search_term in annotation["label"]):
                    return True
        return False
    
    def stop(self):
        """请求停止线程"""
        self.running = False