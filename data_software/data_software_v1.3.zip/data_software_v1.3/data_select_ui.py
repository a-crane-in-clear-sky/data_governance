import os
import json
import datetime
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStatusBar,
                             QLineEdit, QPushButton, QLabel, QTextEdit, QFileDialog, QProgressBar,
                             QShortcut, QGroupBox, QSizePolicy, QFrame, QMenu, QAction, QMessageBox)
from PyQt5.QtGui import QPixmap, QImage, QPainter, QPen, QColor, QKeySequence, QFont, QIcon
from PyQt5.QtCore import Qt, QPoint, QThread, pyqtSignal
from search_worker import SearchWorker

class DataSelectUI(QWidget):
    def __init__(self):
        super().__init__()
        
        # 初始化变量
        self.images_path = ""
        self.labels_path = ""
        self.search_results = []
        self.current_index = 0
        self.show_bbox = False
        self.current_image_with_bbox = None
        self.search_term = ""  # 存储当前的搜索关键词
        self.saved_count = 0   # 记录已保存的图片数量
        self.state_file = "data_cleaner_state.json"  # 状态保存文件
        self.search_worker = None  # 用于存储搜索工作线程
        
        # 创建主界面
        self.init_ui()
        self.setup_style()
        
        # 添加快捷键
        self.setup_shortcuts()
        
        # 加载上次的工作状态
        self.load_state()

    def setup_style(self):
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #444466;
                border-radius: 8px;
                margin-top: 1em;
                padding-top: 10px;
                background-color: rgba(30, 30, 50, 180);
                color: #c0c0e0;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QLabel {
                color: #c0c0e0;
            }
            QPushButton {
                background-color: rgba(60, 60, 100, 200);
                color: #e0e0ff;
                border: 1px solid #4a4a7a;
                border-radius: 4px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: rgba(80, 80, 130, 220);
                border: 1px solid #6a6aaa;
            }
            QPushButton:pressed {
                background-color: rgba(100, 100, 160, 240);
            }
            QLineEdit, QTextEdit {
                background-color: rgba(25, 25, 40, 200);
                color: #e0e0ff;
                border: 1px solid #444466;
                border-radius: 4px;
                padding: 5px;
            }
            QProgressBar {
                border: 1px solid #444466;
                border-radius: 4px;
                text-align: center;
                background-color: rgba(20, 20, 35, 200);
            }
            QProgressBar::chunk {
                background-color: #4a86e8;
                border-radius: 4px;
            }
        """)

    
    def setup_shortcuts(self):
        """设置所有快捷键"""
        # 保存: Ctrl+S
        save_shortcut = QShortcut(QKeySequence("Ctrl+S"), self)
        save_shortcut.activated.connect(self.save_current_image)
        
        # 上一张: 左键或上键
        prev_shortcut1 = QShortcut(QKeySequence(Qt.Key_Left), self)
        prev_shortcut1.activated.connect(self.show_previous)
        prev_shortcut2 = QShortcut(QKeySequence(Qt.Key_Up), self)
        prev_shortcut2.activated.connect(self.show_previous)
        
        # 下一张: 右键或下键
        next_shortcut1 = QShortcut(QKeySequence(Qt.Key_Right), self)
        next_shortcut1.activated.connect(self.show_next)
        next_shortcut2 = QShortcut(QKeySequence(Qt.Key_Down), self)
        next_shortcut2.activated.connect(self.show_next)
        
        # 删除(不保存): Backspace或Delete
        discard_shortcut1 = QShortcut(QKeySequence(Qt.Key_Backspace), self)
        discard_shortcut1.activated.connect(self.discard_current_image)
        discard_shortcut2 = QShortcut(QKeySequence(Qt.Key_Delete), self)
        discard_shortcut2.activated.connect(self.discard_current_image)
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 标题
        self.title_label = QLabel("图像数据（已标&未标）高质量筛选")
        self.title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #8ab4f8;")
        self.title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title_label)
        
        # 路径选择区域
        self.path_group = QGroupBox("数据路径设置")
        path_layout = QHBoxLayout()

        # 左侧路径选择部分（保持原有）
        left_path_layout = QHBoxLayout()

        # 图像路径
        self.images_group = QGroupBox("图像路径")
        images_layout = QVBoxLayout()
        self.images_path_label = QLabel("未选择")
        images_layout.addWidget(self.images_path_label)

        self.images_btn = QPushButton("选择图像文件夹")
        images_layout.addWidget(self.images_btn)

        self.images_group.setLayout(images_layout)

        # 标签路径
        self.labels_group = QGroupBox("标签路径")
        labels_layout = QVBoxLayout()
        self.labels_path_label = QLabel("未选择")
        labels_layout.addWidget(self.labels_path_label)

        self.labels_btn = QPushButton("选择标签文件夹")
        labels_layout.addWidget(self.labels_btn)

        self.labels_group.setLayout(labels_layout)

        left_path_layout.addWidget(self.images_group, 1)
        left_path_layout.addWidget(self.labels_group, 1)

        # 新增右侧文本显示区域
        right_display = QGroupBox("已保存图像数量")
        right_layout = QVBoxLayout()
        self.saved_count_label = QLabel("0")
        self.saved_count_label.setMaximumHeight(120)  # 限制高度
        right_layout.addWidget(self.saved_count_label)
        right_display.setLayout(right_layout)

        # 组合布局
        path_layout.addLayout(left_path_layout, 4)  # 4/5宽度给路径选择
        path_layout.addWidget(right_display, 1)    # 1/5宽度给信息提示

        self.path_group.setLayout(path_layout)
        layout.addWidget(self.path_group)
        
        # 搜索区域
        self.search_group = QGroupBox("数据筛选")
        search_layout = QVBoxLayout()
        
        # 搜索输入
        search_input_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("输入搜索关键词（如'商业客机'），留空则提取所有文件")
        search_input_layout.addWidget(self.search_input, 4)
        
        self.search_button = QPushButton("开始搜索")
        search_input_layout.addWidget(self.search_button, 1)
        
        search_layout.addLayout(search_input_layout)
        
        # 去重按钮
        dedup_layout = QHBoxLayout()
        self.dedup_button = QPushButton("算法去重（开发中）")
        self.dedup_button.setToolTip("使用算法去除重复图像")
        dedup_layout.addWidget(self.dedup_button)
        
        self.load_dedup_button = QPushButton("读取算法去重结果")
        self.load_dedup_button.setToolTip("读取算法去重结果的JSON文件")
        dedup_layout.addWidget(self.load_dedup_button)
        
        dedup_layout.addStretch()
        search_layout.addLayout(dedup_layout)
        self.search_group.setLayout(search_layout)
        layout.addWidget(self.search_group)
        
        # 显示区域
        self.display_group = QGroupBox("数据预览")
        display_layout = QHBoxLayout()
        
        # 图像预览
        self.image_group = QGroupBox("图像预览")
        image_layout = QVBoxLayout()
        
        self.image_display = QLabel()
        self.image_display.setAlignment(Qt.AlignCenter)
        self.image_display.setMinimumSize(400, 300)
        self.image_display.setStyleSheet("border: 1px solid #444466; background-color: rgba(20, 20, 35, 200);")
        
        self.image_filename_label = QLabel("图像文件名: ")
        self.image_filename_label.setAlignment(Qt.AlignCenter)
        
        image_layout.addWidget(self.image_display, 3)
        image_layout.addWidget(self.image_filename_label, 1)
        self.image_group.setLayout(image_layout)
        
        # JSON预览
        self.json_group = QGroupBox("标签详情")
        json_layout = QVBoxLayout()
        
        self.json_display = QTextEdit()
        self.json_display.setReadOnly(True)
        
        self.json_filename_label = QLabel("标签文件名: ")
        self.json_filename_label.setAlignment(Qt.AlignCenter)
        
        json_layout.addWidget(self.json_display, 3)
        json_layout.addWidget(self.json_filename_label, 1)
        self.json_group.setLayout(json_layout)
        
        display_layout.addWidget(self.image_group, 1)
        display_layout.addWidget(self.json_group, 1)
        self.display_group.setLayout(display_layout)
        layout.addWidget(self.display_group, 1)
        
        # 控制区域
        self.control_group = QGroupBox("数据操作")
        control_layout = QVBoxLayout()
        
        # 进度条
        progress_layout = QHBoxLayout()
        self.progress_label = QLabel("0/0")
        self.progress_label.setFixedWidth(80)
        self.progress_bar = QProgressBar()
        self.progress_bar.setFormat("%p% (%v/%m)")
        progress_layout.addWidget(self.progress_label)
        progress_layout.addWidget(self.progress_bar)
        control_layout.addLayout(progress_layout)
        
        # 导航按钮
        nav_layout = QHBoxLayout()
        self.prev_button = QPushButton("上一张 (←/↑)")
        self.prev_button.setEnabled(False)
        nav_layout.addWidget(self.prev_button)
        
        self.next_button = QPushButton("下一张 (→/↓)")
        self.next_button.setEnabled(False)
        nav_layout.addWidget(self.next_button)
        control_layout.addLayout(nav_layout)
        
        # 操作按钮
        action_layout = QHBoxLayout()
        self.save_button = QPushButton("保存当前图像 (Ctrl+S)")
        self.save_button.setEnabled(False)
        action_layout.addWidget(self.save_button)
        
        self.discard_button = QPushButton("不保存并剔除 (Del/Backs)")
        self.discard_button.setEnabled(False)
        action_layout.addWidget(self.discard_button)
        control_layout.addLayout(action_layout)
        
        # 检测框按钮
        bbox_layout = QHBoxLayout()
        self.show_bbox_button = QPushButton("显示检测框")
        bbox_layout.addWidget(self.show_bbox_button)
        
        self.hide_bbox_button = QPushButton("隐藏检测框")
        bbox_layout.addWidget(self.hide_bbox_button)
        control_layout.addLayout(bbox_layout)
        
        self.control_group.setLayout(control_layout)
        layout.addWidget(self.control_group)
        
        self.setLayout(layout)
        
        self.status_bar = QStatusBar()
        self.status_label = QLabel("就绪")
        
        # 设置状态栏样式
        self.status_bar.setStyleSheet("""
            QStatusBar {
                background-color: #333344;
                color: #ffffff;
                border-top: 1px solid #444466;
                padding-left: 8px;
            }
        """)
        
        # 添加状态标签到状态栏
        self.status_bar.addWidget(self.status_label)
        
        # 将状态栏添加到主布局
        layout.addWidget(self.status_bar)


        # 初始化示例数据
        self.show_example_data()

        # 连接按钮信号
        self.images_btn.clicked.connect(self.select_images_path)
        self.labels_btn.clicked.connect(self.select_labels_path)
        self.search_button.clicked.connect(self.start_search_thread)
        self.dedup_button.clicked.connect(self.dedup_images)
        self.load_dedup_button.clicked.connect(self.load_dedup_results)
        self.prev_button.clicked.connect(self.show_previous)
        self.next_button.clicked.connect(self.show_next)
        self.save_button.clicked.connect(self.save_current_image)
        self.discard_button.clicked.connect(self.discard_current_image)
        self.show_bbox_button.clicked.connect(self.toggle_bbox_display)
        self.hide_bbox_button.clicked.connect(self.toggle_bbox_display)
    
    def resizeEvent(self, event):
        """当窗口大小改变时重新缩放图像"""
        super().resizeEvent(event)
        # 重新加载当前图像以适应当前窗口大小
        if hasattr(self, 'current_image_path') and self.current_image_path:
            self.show_current_image()

    # ========================================================
    # 功能函数
    # ========================================================

    def show_example_data(self):
        """显示示例数据"""
        # 创建示例图像
        pixmap = QPixmap(600, 400)
        pixmap.fill(QColor(30, 30, 50))
        
        painter = QPainter(pixmap)
        painter.setPen(QColor(100, 180, 255))
        painter.setFont(QFont("Arial", 24))
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "图像预览区域")
        painter.end()
        
        self.image_display.setPixmap(pixmap)
        self.image_filename_label.setText("图像文件名: example_image.jpg")
        
        # 显示示例JSON
        example_json = {
            "filename": "example_image.jpg",
            "annotations": [
                {
                    "class": "airplane",
                    "label": "commercial",
                    "coordinates": "100,200,300,400"
                }
            ]
        }
        self.json_display.setPlainText(str(example_json))
        self.json_filename_label.setText("标签文件名: example_image.json")
        
        # 更新进度状态
        self.progress_bar.setRange(0, 1)
        self.progress_bar.setValue(1)
        self.progress_label.setText("1/1")

    def show_current_image(self):
        """显示当前图像（根据窗口大小保持宽高比调整）"""
        if self.images_path and self.current_image_path:
            image = QImage(self.current_image_path)
            if not image.isNull():
                # 如果需要显示检测框，则绘制检测框
                if self.show_bbox:
                    self.current_image_with_bbox = self.draw_bounding_boxes(image.copy(), self.current_basename)
                    display_image = self.current_image_with_bbox
                else:
                    display_image = image.copy()
                
                # 获取容器大小（减去边距以保持间距）
                container_size = self.image_display.size()
                
                # 计算保持宽高比的缩放尺寸
                img_width = image.width()
                img_height = image.height()
                
                # 计算缩放比例（保持宽高比）
                scale_factor = min(
                    container_size.width() / img_width,
                    container_size.height() / img_height
                )
                
                # 应用缩放比例
                scaled_width = int(img_width * scale_factor)
                scaled_height = int(img_height * scale_factor)
                
                # 缩放图像
                scaled_image = display_image.scaled(
                    scaled_width,
                    scaled_height,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
                
                # 直接设置图像到标签
                self.image_display.setPixmap(QPixmap.fromImage(scaled_image))
    
    # ========================================================
    # 多进程处理方法
    # ========================================================
    def start_search_thread(self):
        """启动搜索线程（多进程处理）"""
        if not self.labels_path:
            self.status_label.setText("请先选择标签目录！")
            return
            
        search_term = self.search_input.text().strip()
        # 修改：允许空搜索词，提取整个文件夹
            
        # 存储搜索关键词，用于后续绘制检测框
        self.search_term = search_term
            
        # 重置状态
        self.search_results = []
        self.output_file = f"{search_term}.json" if search_term else "all_files.json"
        self.update_progress_bar(0, 0)
        
        # 禁用搜索按钮
        self.search_button.setEnabled(False)
        self.search_button.setText("搜索中...")
        
        # 创建并启动新线程
        self.search_worker = SearchWorker(self.labels_path, search_term)
        
        # 连接信号
        self.search_worker.search_finished.connect(self.handle_search_results)
        self.search_worker.progress_updated.connect(self.update_search_progress)
        self.search_worker.error_occurred.connect(self.handle_search_error)
        
        # 启动线程
        self.search_worker.start()
    
    def update_search_progress(self, processed, total):
        """更新搜索进度（来自工作线程）"""
        self.status_label.setText(f"正在搜索... 已完成 {processed}/{total}")
        self.update_progress_bar(processed, total)
    
    def handle_search_results(self, results, term):
        """处理搜索结果（来自工作线程）"""
        self.search_results = results
        self.search_term = term
        self.search_button.setEnabled(True)
        self.search_button.setText("搜索")
        
        # 读取已保存的数量
        self.update_saved_count()
        
        if not self.search_results:
            self.status_label.setText(f"未找到包含 '{term}' 的文件" if term else "标签文件夹中没有找到任何JSON文件")
            self.prev_button.setEnabled(False)
            self.next_button.setEnabled(False)
            
            # 重置进度条
            self.update_progress_bar(0, 0)
            return
            
        # 保存结果到文件
        try:
            with open(self.output_file, 'w', encoding='utf-8') as f:
                json.dump(self.search_results, f, ensure_ascii=False, indent=2)
            self.status_label.setText(f"找到 {len(self.search_results)} 个结果，已保存到 {self.output_file}")
            
            # 显示第一个结果
            self.current_index = 0
            self.show_current_result()
            
            # 启用导航按钮
            self.prev_button.setEnabled(len(self.search_results) > 1)
            self.next_button.setEnabled(len(self.search_results) > 1)
            
            # 保存状态
            self.save_state()
        except Exception as e:
            self.status_label.setText(f"保存结果文件出错: {str(e)}")
    
    def handle_search_error(self, error_msg):
        """处理搜索错误（来自工作线程）"""
        self.status_label.setText(error_msg)
        self.search_button.setEnabled(True)
        self.search_button.setText("搜索")
    
    # ========================================================
    # 新增方法：加载算法去重结果
    # ========================================================
    def load_dedup_results(self):
        """加载算法去重结果的JSON文件"""
        # 打开文件对话框让用户选择JSON文件
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "选择去重结果文件", 
            "", 
            "JSON Files (*.json)"
        )
        
        if not file_path:
            return  # 用户取消选择
            
        try:
            # 读取JSON文件
            with open(file_path, 'r', encoding='utf-8') as f:
                dedup_results = json.load(f)
                
            # 验证数据格式
            if not isinstance(dedup_results, list) or not all(isinstance(item, str) for item in dedup_results):
                raise ValueError("JSON文件格式错误: 应包含字符串列表")
                
            # 更新搜索结果为去重结果
            self.search_results = dedup_results
            self.search_term = "算法去重结果"  # 设置搜索关键词
            self.output_file = file_path
            
            # 更新UI状态
            self.status_label.setText(f"已加载去重结果: {len(self.search_results)} 个文件")
            
            if self.search_results:
                self.current_index = 0
                self.show_current_result()
                
                # 启用导航按钮
                self.prev_button.setEnabled(len(self.search_results) > 1)
                self.next_button.setEnabled(len(self.search_results) > 1)
                
                # 保存状态
                self.save_state()
            else:
                self.status_label.setText("去重结果为空")
                self.prev_button.setEnabled(False)
                self.next_button.setEnabled(False)
                self.update_progress_bar(0, 0)
                
        except Exception as e:
            QMessageBox.critical(self, "加载错误", f"加载去重结果时出错: {str(e)}")
    
    # ========================================================
    # 新增方法：算法去重
    # ========================================================
    def dedup_images(self):
        """算法去重功能（保留接口）"""
        # 这里只实现基本提示，实际去重算法需要根据具体需求实现
        QMessageBox.information(self, "算法去重", "去重功能已预留接口，后续可在此处实现图像去重算法。")
        self.status_label.setText("去重功能接口已预留，待实现具体算法")
    
    # ========================================================
    # 修改后的路径选择方法
    # ========================================================
    def select_images_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择图像文件夹")
        if path:
            self.images_path = path
            self.images_path_label.setText(path)
            self.images_path_label.setToolTip(path)
            self.status_label.setText(f"已选择图像路径: {path}")
            self.save_state()  # 保存状态
    
    def select_images_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "选择图像文件", "", "Images (*.png *.jpg *.jpeg *.bmp *.tif)")
        if file:
            self.images_path = os.path.dirname(file)
            self.images_path_label.setText(self.images_path)
            self.images_path_label.setToolTip(self.images_path)
            self.status_label.setText(f"已选择图像文件: {os.path.basename(file)}")
            self.save_state()  # 保存状态
    
    def select_labels_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择标签文件夹")
        if path:
            self.labels_path = path
            self.labels_path_label.setText(path)
            self.labels_path_label.setToolTip(path)
            self.status_label.setText(f"已选择标签路径: {path}")
            self.save_state()  # 保存状态
    
    def select_labels_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "选择标签文件", "", "JSON Files (*.json)")
        if file:
            self.labels_path = os.path.dirname(file)
            self.labels_path_label.setText(self.labels_path)
            self.labels_path_label.setToolTip(self.labels_path)
            self.status_label.setText(f"已选择标签文件: {os.path.basename(file)}")
            self.save_state()  # 保存状态
    
    # ========================================================
    # 其他方法（与原代码相同）
    # ========================================================
    def update_saved_count(self):
        """更新已保存的图片数量"""
        if hasattr(self, 'output_file') and hasattr(self, 'search_term') and self.search_term:
            try:
                filter_file = f"{self.search_term}(筛选).json" if self.search_term else "all_files(筛选).json"
                if os.path.exists(filter_file):
                    with open(filter_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    self.saved_count = len(data)
                    self.saved_count_label.setText(f"{self.saved_count}")
                else:
                    self.saved_count = 0
                    self.saved_count_label.setText("0")
            except Exception as e:
                print(f"更新保存数量出错: {str(e)}")
    
    def show_current_result(self):
        if not self.search_results or self.current_index < 0 or self.current_index >= len(self.search_results):
            return
            
        # 更新进度条
        self.update_progress_bar(self.current_index + 1, len(self.search_results))
        
        basename = self.search_results[self.current_index]
        self.current_basename = basename
        
        # 显示图像文件名
        self.image_filename = basename
        found_ext = ""
        
        # 显示图像
        image_found = False
        image_path = ""
        
        if self.images_path:
            # 尝试常见图像格式
            for ext in ['.jpg', '.png', '.tif', '.bmp', '.jpeg', '.JPG', '.PNG']:
                test_path = os.path.join(self.images_path, f"{basename}{ext}")
                if os.path.exists(test_path):
                    image_found = True
                    image_path = test_path
                    self.image_filename = f"{basename}{ext}"
                    found_ext = ext
                    break
        
        if image_found:
            self.current_image_path = image_path
            self.show_current_image()
            self.image_filename_label.setText(f"图像文件名: {self.image_filename}")
        else:
            if self.images_path:
                self.image_filename_label.setText(f"图像文件不存在: {basename}.*")
            else:
                self.image_filename_label.setText("请先选择图像文件夹")
        
        # 显示JSON内容
        json_path = os.path.join(self.labels_path, f"{basename}.json")
        json_filename = f"{basename}.json"
        self.json_filename_label.setText(f"标签文件名: {json_filename}")
        
        if os.path.exists(json_path):
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                    formatted_json = json.dumps(json_data, ensure_ascii=False, indent=2)
                    self.json_display.setPlainText(formatted_json)
            except Exception as e:
                self.json_display.setPlainText(f"读取JSON文件出错:\n{str(e)}")
        else:
            self.json_display.setPlainText(f"JSON文件不存在: {json_path}")
        
        # 启用保存按钮
        self.save_button.setEnabled(True)
        self.discard_button.setEnabled(True)
    
    def update_progress_bar(self, current, total):
        """更新进度条显示"""
        if total > 0:
            # 计算百分比
            percentage = int((current / total) * 100)
            
            # 更新进度文本
            self.progress_label.setText(f"{current}/{total}")
            
            # 更新进度条
            self.progress_bar.setValue(percentage)
            self.progress_bar.setFormat(f"{current}/{total} ({percentage}%)")
        else:
            self.progress_label.setText("0/0")
            self.progress_bar.setValue(0)
            self.progress_bar.setFormat("0/0 (0%)")
    
    def draw_bounding_boxes(self, image, basename):
        """绘制仅包含搜索关键词的检测框"""
        json_path = os.path.join(self.labels_path, f"{basename}.json")
        if not os.path.exists(json_path):
            return image
            
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
                
            painter = QPainter(image)
            pen = QPen(QColor(255, 0, 0), 2)  # 红色，2像素宽
            painter.setPen(pen)
            
            # 只绘制包含搜索关键词的检测框
            if "annotations" in json_data:
                for annotation in json_data["annotations"]:
                    # 检查标注是否包含搜索关键词
                    if "coordinates of the corner point(Col,Row)" in annotation:
                        if ("class" in annotation and self.search_term in annotation["class"]) or \
                           ("label" in annotation and self.search_term in annotation["label"]):
                            
                            points = []
                            for coord in annotation["coordinates of the corner point(Col,Row)"]:
                                col, row = map(int, coord.split(','))
                                points.append(QPoint(col, row))
                            
                            # 绘制多边形
                            for i in range(len(points)):
                                painter.drawLine(points[i], points[(i+1)%len(points)])
                            
                            # 标注类别和ID
                            if "class" in annotation and "label" in annotation and "id" in annotation:
                                label = f"{annotation['class']} {annotation['label']} {annotation['id']}"
                                painter.drawText(points[0], label)
            
            painter.end()
            return image
            
        except Exception as e:
            print(f"绘制检测框出错: {str(e)}")
            return image
    
    def toggle_bbox_display(self):
        sender = self.sender()
        if sender == self.show_bbox_button:
            self.show_bbox = True
        else:
            self.show_bbox = False
        self.show_current_image()  # 刷新显示
        self.save_state()  # 保存状态
    
    def save_current_image(self):
        if not self.search_results or self.current_index < 0 or self.current_index >= len(self.search_results):
            return
            
        search_term = self.search_input.text().strip()
        if not search_term:
            self.status_label.setText("请先输入搜索关键词！")
            return
            
        basename = self.search_results[self.current_index]
        output_file = f"{search_term}(筛选).json"
        
        try:
            # 读取或创建筛选文件
            if os.path.exists(output_file):
                with open(output_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = []
            
            # 添加当前文件名（如果不存在）
            if basename not in data:
                data.append(basename)
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                self.status_label.setText(f"已保存 {basename} 到 {output_file}")
                self.saved_count += 1
                self.saved_count_label.setText(f"{self.saved_count}")
            else:
                self.status_label.setText(f"{basename} 已在 {output_file} 中")
                
            # 移动到下一张
            if self.current_index < len(self.search_results) - 1:
                self.current_index += 1
                self.show_current_result()
            else:
                self.next_button.setEnabled(False)
                self.status_label.setText(f"所有{len(self.search_results)}张图片已处理完成！")
            
            # 保存状态
            self.save_state()
                
        except Exception as e:
            self.status_label.setText(f"保存失败: {str(e)}")
    
    def discard_current_image(self):
        if not self.search_results or self.current_index < 0 or self.current_index >= len(self.search_results):
            return
            
        search_term = self.search_input.text().strip()
        if not search_term:
            self.status_label.setText("请先输入搜索关键词！")
            return
            
        basename = self.search_results[self.current_index]
        output_file = f"{search_term}(筛选).json"
        
        try:
            if os.path.exists(output_file):
                with open(output_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # 移除当前文件名（如果存在）
                if basename in data:
                    data.remove(basename)
                    with open(output_file, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    self.status_label.setText(f"已从 {output_file} 中移除 {basename}")
                    # 如果文件在筛选列表中，更新保存数量
                    self.update_saved_count()
                else:
                    self.status_label.setText(f"{basename} 不在 {output_file} 中")
            else:
                self.status_label.setText(f"{output_file} 不存在")
                
            # 移动到下一张
            if self.current_index < len(self.search_results) - 1:
                self.current_index += 1
                self.show_current_result()
            else:
                self.next_button.setEnabled(False)
                self.status_label.setText(f"所有{len(self.search_results)}张图片已处理完成！")
            
            # 保存状态
            self.save_state()
                
        except Exception as e:
            self.status_label.setText(f"剔除失败: {str(e)}")
    
    def show_previous(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.show_current_result()
            self.next_button.setEnabled(True)
            if self.current_index == 0:
                self.prev_button.setEnabled(False)
            
            # 保存状态
            self.save_state()
    
    def show_next(self):
        if self.current_index < len(self.search_results) - 1:
            self.current_index += 1
            self.show_current_result()
            self.prev_button.setEnabled(True)
            if self.current_index == len(self.search_results) - 1:
                self.next_button.setEnabled(False)
            
            # 保存状态
            self.save_state()
    
    def load_state(self):
        """加载上次的工作状态"""
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    state_data = json.load(f)
                
                # 恢复路径
                if 'images_path' in state_data:
                    self.images_path = state_data['images_path']
                    self.images_path_label.setText(self.images_path)
                
                if 'labels_path' in state_data:
                    self.labels_path = state_data['labels_path']
                    self.labels_path_label.setText(self.labels_path)
                
                # 恢复搜索状态
                if 'search_term' in state_data and state_data['search_term']:
                    self.search_term = state_data['search_term']
                    self.search_input.setText(self.search_term)
                    
                    # 恢复搜索结果
                    if 'search_results' in state_data:
                        self.search_results = state_data['search_results']
                    
                    # 恢复当前索引
                    if 'current_index' in state_data and self.search_results:
                        self.current_index = state_data['current_index']
                        if self.current_index >= len(self.search_results):
                            self.current_index = 0
                    
                    # 恢复保存数量
                    if 'saved_count' in state_data:
                        self.saved_count = state_data['saved_count']
                        self.saved_count_label.setText(str(self.saved_count))
                    
                    # 恢复检测框状态
                    if 'show_bbox' in state_data:
                        self.show_bbox = state_data['show_bbox']
                    
                    # 更新UI状态
                    if self.search_results:
                        self.status_label.setText(f"已恢复上次的搜索: {self.search_term} ({len(self.search_results)} 张图片)")
                        
                        # 启用按钮
                        self.prev_button.setEnabled(self.current_index > 0)
                        self.next_button.setEnabled(self.current_index < len(self.search_results) - 1)
                        self.save_button.setEnabled(True)
                        self.discard_button.setEnabled(True)
                        
                        # 显示当前结果
                        self.show_current_result()
        except Exception as e:
            print(f"加载状态出错: {str(e)}")
    
    def save_state(self):
        """保存当前工作状态"""
        try:
            state_data = {
                'images_path': self.images_path,
                'labels_path': self.labels_path,
                'search_term': self.search_term,
                'search_results': self.search_results,
                'current_index': self.current_index,
                'saved_count': self.saved_count,
                'show_bbox': self.show_bbox,
                'last_saved': str(datetime.datetime.now())
            }
            
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存状态出错: {str(e)}")
    
    def closeEvent(self, event):
        """窗口关闭时保存状态，并确保停止任何运行的线程"""
        # 停止正在运行的搜索线程
        if self.search_worker and self.search_worker.isRunning():
            self.search_worker.stop()
            self.search_worker.quit()
            self.search_worker.wait()
        
        # 保存状态
        self.save_state()
        event.accept()


if __name__ == "__main__":
    # 设置环境变量解决OpenGL问题
    os.environ["QT_XCB_FORCE_SOFTWARE_OPENGL"] = "1"
    
    app = QApplication([])
    
    # 高DPI支持
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    window = ImageDataCleaner()
    window.show()
    app.exec_()